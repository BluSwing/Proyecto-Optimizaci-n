from chromosome import Chromosome as BaseChromosome
import population
from nodes import Deport, Customer, CustomerDistanceTable
from csv_reader import csv_read
import ga_params


class Chromosome(BaseChromosome):
    @staticmethod
    def get_distance(source: int, dest: int) -> float:
        global customers_distance_table     # type: CustomerDistanceTable
        return customers_distance_table.get_distance(source, dest)

    @staticmethod
    def get_node(index: int) -> Customer:
        global customers
        return customers[index]


population.Chromosome = Chromosome

run_file_name = input("Enter run file name [default: C101_200]: ")
if not run_file_name:
    run_file_name = ga_params.run_file['name']
print('Running: "' + run_file_name + '"')

customers_input_read = csv_read(run_file_name, header_map=ga_params.run_file['header_map'])
customers = [Deport(**customers_input_read[0])]
customers += [Customer(**customer_dict) for customer_dict in customers_input_read]

customers_distance_table = CustomerDistanceTable(customers)

ga_pop = population.Population(chromosome_width=len(customers), run_file_name=run_file_name, **ga_params.population)

# Medir tiempo de ejecución
import time
start_time = time.time()

best_chrome, total_time = ga_pop.evolve()

end_time = time.time()
execution_time = end_time - start_time
print(f"Best Solution:\n{best_chrome}")
print(f"Total Execution Time: {total_time}")
print(f"Total Execution Time (seconds): {execution_time}")
